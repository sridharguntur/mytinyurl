create table urlmapping(
tinyurl varchar(50) not null,
bigurl varchar(200) not null,
primary key(tinyurl)
);