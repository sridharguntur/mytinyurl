insert into urlmapping(tinyurl,bigurl) values('abc','/movies/bigger/abc');
insert into urlmapping(tinyurl,bigurl)  values('xyz','/movies/bigger/AXY');
insert into urlmapping(tinyurl,bigurl)  values('xrt','/movies/bigger/ab');
